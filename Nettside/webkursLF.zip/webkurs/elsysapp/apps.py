from django.apps import AppConfig


class ElsysappConfig(AppConfig):
    name = 'elsysapp'
